return {
  {
    "LazyVim/LazyVim",
    opts = {
      -- Set gruvbox as default colorscheme
      colorscheme = "gruvbox",
    },
  },
}

